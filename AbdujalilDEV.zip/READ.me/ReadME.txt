				Our Social Media Pages !

	Telegram:
		1. https://t.me/ResponsiveTemplatesBot  -  BOT
		2. https://t.me/Abdujalil_IT_Blog  -  MY BLOG CHANNEL
		3. https://t.me/IT_CLUB_ONLINE  -  MY PROJECT CHANNEL
		4. https://t.me/VideoDarslar3438_bot  -  BOT
		5. https://t.me/VideoDasrlarBepulBot  -  BOT
		6. https://t.me/HomeA1oneBot  -  BOT
	
	Instagram:
		1. https://www.instagram.com/abdujalil_developer/
		2. https://www.instagram.com/abdujalil_developerr/


	Facebook:
		1. https://www.facebook.com/abdujalil.chirmashev/

	LinkedIn:
		1. https://www.linkedin.com/in/abdujalil-chirmashev-459417223
	
	YouTube:
		1. https://www.youtube.com/channel/UCdgy8-IHEmmkwOetI441_lg

 © Abdujalil Chirmashev
 © Studio Abdujalil Media
 © Abdujalil Media